<?php

include_once ('src/sadar.lib.php'); // Import Library file

// Account details
$apikey="3MvDA19eRx9gNysD2hODkXly29MzIqaZ";
$apitoken="sszc1521640029";
$SadarSMS = new SadarSMS($apikey, $apitoken); // User Gateway Sms

// Process your response here
$response = $SadarSMS->check_balance();
if($response['status'] == "okey")
		echo $response['balance'];
	else
		echo $response['message'];
		
	

?>